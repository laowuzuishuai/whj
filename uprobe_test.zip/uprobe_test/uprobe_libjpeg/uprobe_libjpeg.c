#include <stdio.h>
#include <jpeglib.h>
#include <stdlib.h>

void compress_decompress(char *input_filename, char *output_filename) {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;

    FILE *input_file = fopen(input_filename, "rb");
    if (!input_file) {
        printf("Error opening input file %s\n", input_filename);
        exit(1);
    }

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_decompress(&cinfo);
    jpeg_stdio_src(&cinfo, input_file);
    (void) jpeg_read_header(&cinfo, TRUE);
    (void) jpeg_start_decompress(&cinfo);

    FILE *output_file = fopen(output_filename, "wb");
    if (!output_file) {
        printf("Error opening output file %s\n", output_filename);
        exit(1);
    }

    struct jpeg_compress_struct cinfo_com;
    cinfo_com.err = jpeg_std_error(&jerr);
    jpeg_create_compress(&cinfo_com);
    jpeg_stdio_dest(&cinfo_com, output_file);

    cinfo_com.image_width = cinfo.output_width;
    cinfo_com.image_height = cinfo.output_height;
    cinfo_com.input_components = cinfo.num_components;
    cinfo_com.in_color_space = cinfo.out_color_space;

    jpeg_set_defaults(&cinfo_com);
    jpeg_start_compress(&cinfo_com, TRUE);

    JSAMPROW row_pointer[1];
    int row_stride = cinfo.output_width * cinfo.num_components;

    while (cinfo.output_scanline < cinfo.output_height) {
        row_pointer[0] = (JSAMPROW) malloc(row_stride);
        (void) jpeg_read_scanlines(&cinfo, row_pointer, 1);
        jpeg_write_scanlines(&cinfo_com, row_pointer, 1);
        free(row_pointer[0]);
    }

    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    fclose(input_file);

    jpeg_finish_compress(&cinfo_com);
    jpeg_destroy_compress(&cinfo_com);
    fclose(output_file);
}

int main() {
    char *input_filename = "input_images/input.jpg";
    char *output_filename = "output_images/output.jpg";
    compress_decompress(input_filename, output_filename);
    return 0;
}

