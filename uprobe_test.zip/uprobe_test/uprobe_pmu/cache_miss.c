#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ARRAY_SIZE 10000
#define ITERATIONS 100000

void simulateCacheMiss(int* array) {
    for (int iter = 0; iter < ITERATIONS; ++iter) {
        for (int i = 0; i < ARRAY_SIZE; ++i) {
            // 访问数组元素，可能导致缓存未命中
            array[i]++;
        }
    }
}

int main() {
    // 初始化一个大数组
    int* largeArray = (int*)malloc(ARRAY_SIZE * sizeof(int));

    // 记录开始时间
    clock_t start = clock();

    // 模拟可能导致缓存未命中的操作
    simulateCacheMiss(largeArray);

    // 记录结束时间
    clock_t end = clock();
    double duration = ((double)(end - start)) / CLOCKS_PER_SEC * 1000000;

    printf("函数执行时间：%f 微秒\n", duration);

    // 释放分配的内存
    free(largeArray);

    return 0;
}
