#include <linux/module.h>
#include <linux/ptrace.h>
#include <linux/uprobes.h>
#include <linux/namei.h>
#include <linux/moduleparam.h>
#include <linux/cpumask.h>
#include <asm/msr.h>
#include <linux/kernel.h>
#include <linux/init.h>

MODULE_AUTHOR("john doe");
MODULE_LICENSE("GPL v2");

#define LLC_EVENT 0x064306A3            //打开使能、用户模式、内核模式、掩码、事件码。cycle_activity.stalls_l3_miss
#define UNHALTED_EVENT 0x0043013c       //CPU_CLK_UNHALTED.REF_XCLK
#define ONE_UNHALTED_EVENT 0x0043023C   //CPU_CLK_UNHALTED.ONE_THREAD_ACTIVE
#define DELIVERED_EVENT 0x0042019C      //IDQ_UOPS_NOT_DELIVERED.CORE
#define ISSUED_EVENT 0x0043010E         //UOPS_ISSUED.ANY
#define RECOVERY_CYCLES_EVENT 0x0043010D //INT_MISC.RECOVERY_CYCLES_ANY
#define RETIRED_EVENT 0x004302C2        //UOPS_RETIRED.RETIRE_SLOTS
#define DELIVERED_0_EVENT 0x0443019C    //IDQ_UOPS_NOT_DELIVERED.CYCLES_0_UOPS_DELIV.CORE
#define MITE_EVENT 0x01432479           //IDQ.ALL_MITE_CYCLES_ANY_UOPS
#define MITE_4_EVENT 0x04432479         //IDQ.ALL_MITE_CYCLES_4_UOPS
#define DSB_4_EVENT 0x04431879          //IDQ.ALL_DSB_CYCLES_4_UOPS
#define DSB_EVENT 0x01431879            //IDQ.ALL_DSB_CYCLES_ANY_UOPS
#define MEM_ANY_EVENT 0x144314A3        //CYCLE_ACTIVITY.STALLS_MEM_ANY
#define BOUND_ON_STORES_EVENT 0x004340A6//EXE_ACTIVITY.BOUND_ON_STORES
#define STALLS_TOTAL_EVENT 0x044304A3   //CYCLE_ACTIVITY.STALLS_TOTAL
#define EXE_1_EVENT 0x004302A6          //EXE_ACTIVITY.1_PORTS_UTIL
#define EXE_2_EVENT 0x004304A6          //EXE_ACTIVITY.2_PORTS_UTIL
#define MSR_FIXED_CTR1 0x30A            //CPU_CLK_UNHALTED.THREAD，固定计数器

#define IA32_PERF_GLOBAL_CTRL_ENABLE 0x70000000f// 使能
#define IA32_PERF_FIXED_CTRL_ENABLE 0x333       // 使能
//#define ARR_SIZE (24 * 1024 * 1024)           // 数组大小24MB
//#define ELEMENT_SIZE sizeof(int)
//#define LOOP_ITERATIONS (200)                   // 重复次数
#define TARGET_CPU 2 


static unsigned long long pre_llc_miss = 0;
static unsigned long long pre_retired = 0;
static unsigned long long pre_cycles = 0;

static unsigned long long post_llc_miss = 0;
static unsigned long long post_retired = 0;
static unsigned long long post_cycles = 0;


static char *filename;
module_param(filename, charp, S_IRUGO);

static long offset;
module_param(offset, long, S_IRUGO);

static long long get_cpu_cycles(void)
{
    return rdtsc();  // 使用x86的rdtsc指令来读取CPU循环计数器
}

static int handler_pre(struct uprobe_consumer *self, struct pt_regs *regs){
    //    pr_info("handler: arg0 = %d arg1 =%d \n", (int)regs->di, (int)regs->si);
    //pr_info("handler_pre");
    wrmsrl_on_cpu(TARGET_CPU, MSR_P6_EVNTSEL0, RETIRED_EVENT);
    wrmsrl_on_cpu(TARGET_CPU, MSR_P6_EVNTSEL1, EXE_2_EVENT);
    rdmsrl_on_cpu(TARGET_CPU, MSR_IA32_PERFCTR0, &pre_llc_miss);
    rdmsrl_on_cpu(TARGET_CPU, MSR_IA32_PERFCTR1, &pre_retired);
    pre_cycles=get_cpu_cycles();
    pr_info("The handler_pre LLC-Miss is: %llu\n", pre_llc_miss);
    pr_info("The handler_pre RETIRED is: %llu\n", pre_retired);
    pr_info("The handler_pre CYCLES is: %lld\n", pre_cycles);

        return 0;
}

static int handler_ret(struct uprobe_consumer *self,
                                unsigned long func,
                                struct pt_regs *regs){
        //pr_info("ret_handler ret = %d \n", (int)regs->ax);
        rdmsrl_on_cpu(TARGET_CPU, MSR_IA32_PERFCTR0, &post_llc_miss);
        rdmsrl_on_cpu(TARGET_CPU, MSR_IA32_PERFCTR1, &post_retired);
        post_cycles=get_cpu_cycles();
    pr_info("The handler_ret LLC-Miss is: %llu\n", post_llc_miss);
    pr_info("The handler_ret RETIRED is: %llu\n", post_retired);
    pr_info("The handler_ret CYCLES is: %lld\n", post_cycles); 
//打印差值
        //pr_info("打印差值");
        pr_info("LLC-Miss Count Difference = %lld\n", post_llc_miss - pre_llc_miss);
        pr_info("Retired Count Difference = %lld\n", post_retired - pre_retired);
        pr_info("CPU Cycles Count Difference = %lld\n", post_cycles - pre_cycles);       
        return 0;
}

static struct uprobe_consumer uc = {
        .handler = handler_pre,
        .ret_handler = handler_ret,
};


static struct inode *inode;

static int __init uprobe_init(void) {
        struct path path;
        int ret;
        int cpu;
        ret = kern_path(filename, LOOKUP_FOLLOW, &path);
        if (ret < 0) {
                pr_err("kern_path failed, returned %d\n", ret);
                return ret;
        }

        inode = igrab(path.dentry->d_inode);
        path_put(&path);

        ret = uprobe_register(inode, offset, &uc);
        if (ret < 0) {
                pr_err("register_uprobe failed, returned %d\n", ret);
                return ret;
        }
    wrmsrl(MSR_CORE_PERF_FIXED_CTR_CTRL, IA32_PERF_FIXED_CTRL_ENABLE);
    wrmsrl(MSR_CORE_PERF_GLOBAL_CTRL, IA32_PERF_GLOBAL_CTRL_ENABLE);

    for_each_possible_cpu(cpu)
    {
        wrmsrl_on_cpu(cpu, MSR_P6_EVNTSEL0, RETIRED_EVENT);
        wrmsrl_on_cpu(cpu, MSR_P6_EVNTSEL1, EXE_2_EVENT);
    }
        return 0;
}

static void __exit uprobe_exit(void) {
int cpu;
   for_each_possible_cpu(cpu)
   {
       wrmsrl_on_cpu(cpu, MSR_IA32_PERFCTR0, 0);
       wrmsrl_on_cpu(cpu, MSR_IA32_PERFCTR1, 0);
   }
        uprobe_unregister(inode, offset, &uc);    
        
}

module_init(uprobe_init);
module_exit(uprobe_exit);
